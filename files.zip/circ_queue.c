#include <stdlib.h>
#include "circ_queue.h"

struct CircQueue {
    Packet *data;
    int capacity;
    int head;
    int tail;
    int count;
    OverflowPolicy policy;
    QueueCounters counters;
};

CircQueue *cq_create(int capacity, OverflowPolicy policy)
{
    if (capacity < 1)
        return NULL;
    CircQueue *q = calloc(1, sizeof *q);
    if (!q)
        return NULL;
    q->data = malloc(sizeof(Packet) * (size_t)capacity);
    if (!q->data) {
        free(q);
        return NULL;
    }
    q->capacity = capacity;
    q->policy = policy;
    return q;
}

void cq_destroy(CircQueue *q)
{
    if (!q)
        return;
    free(q->data);
    free(q);
}

EnqueueResult cq_enqueue(CircQueue *q, const Packet *p)
{
    q->counters.received++;
    if (q->count == q->capacity) {
        if (q->policy == POLICY_REJECT_NEW) {
            q->counters.rejected++;
            return ENQ_REJECTED;
        }
        q->data[q->tail] = *p;
        q->tail = (q->tail + 1) % q->capacity;
        q->head = q->tail;
        q->counters.accepted++;
        q->counters.overwritten++;
        return ENQ_OVERWROTE;
    }
    q->data[q->tail] = *p;
    q->tail = (q->tail + 1) % q->capacity;
    q->count++;
    q->counters.accepted++;
    return ENQ_OK;
}

int cq_dequeue(CircQueue *q, Packet *out)
{
    if (q->count == 0)
        return 0;
    if (out)
        *out = q->data[q->head];
    q->head = (q->head + 1) % q->capacity;
    q->count--;
    q->counters.removed++;
    return 1;
}

int cq_peek(const CircQueue *q, Packet *out)
{
    if (q->count == 0)
        return 0;
    *out = q->data[q->head];
    return 1;
}

void cq_clear(CircQueue *q)
{
    q->head = 0;
    q->tail = 0;
    q->count = 0;
    q->counters = (QueueCounters){0};
}

int cq_count(const CircQueue *q)
{
    return q->count;
}

int cq_capacity(const CircQueue *q)
{
    return q->capacity;
}

int cq_head(const CircQueue *q)
{
    return q->head;
}

int cq_tail(const CircQueue *q)
{
    return q->tail;
}

QueueCounters cq_counters(const CircQueue *q)
{
    return q->counters;
}

int cq_snapshot(const CircQueue *q, Packet *out)
{
    for (int i = 0; i < q->count; i++)
        out[i] = q->data[(q->head + i) % q->capacity];
    return q->count;
}
