#ifndef CIRC_QUEUE_H
#define CIRC_QUEUE_H

#include "queue_common.h"

typedef struct CircQueue CircQueue;

CircQueue *cq_create(int capacity, OverflowPolicy policy);
void cq_destroy(CircQueue *q);
EnqueueResult cq_enqueue(CircQueue *q, const Packet *p);
int cq_dequeue(CircQueue *q, Packet *out);
int cq_peek(const CircQueue *q, Packet *out);
void cq_clear(CircQueue *q);
int cq_count(const CircQueue *q);
int cq_capacity(const CircQueue *q);
int cq_head(const CircQueue *q);
int cq_tail(const CircQueue *q);
QueueCounters cq_counters(const CircQueue *q);
int cq_snapshot(const CircQueue *q, Packet *out);

#endif
