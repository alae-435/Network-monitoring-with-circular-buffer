#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>
#include "packet.h"
#include "queue_common.h"
#include "ref_queue.h"
#include "circ_queue.h"

#ifdef _WIN32
#include <direct.h>
#define MKDIR(d) _mkdir(d)
#else
#define MKDIR(d) mkdir(d, 0755)
#endif

#define LEN(a) ((int)(sizeof(a) / sizeof((a)[0])))
#define MAX_DATASETS 8

typedef struct {
    const char *name;
    void *(*create)(int, OverflowPolicy);
    void (*destroy)(void *);
    EnqueueResult (*enqueue)(void *, const Packet *);
    int (*dequeue)(void *, Packet *);
    int (*count)(const void *);
    QueueCounters (*counters)(const void *);
    int (*snapshot)(const void *, Packet *);
} QueueImpl;

#define DEFINE_IMPL(PFX, LABEL) \
static void *PFX##_w_create(int c, OverflowPolicy p) { return PFX##_create(c, p); } \
static void PFX##_w_destroy(void *q) { PFX##_destroy(q); } \
static EnqueueResult PFX##_w_enqueue(void *q, const Packet *p) { return PFX##_enqueue(q, p); } \
static int PFX##_w_dequeue(void *q, Packet *o) { return PFX##_dequeue(q, o); } \
static int PFX##_w_count(const void *q) { return PFX##_count(q); } \
static QueueCounters PFX##_w_counters(const void *q) { return PFX##_counters(q); } \
static int PFX##_w_snapshot(const void *q, Packet *o) { return PFX##_snapshot(q, o); } \
static const QueueImpl PFX##_impl = { LABEL, PFX##_w_create, PFX##_w_destroy, PFX##_w_enqueue, \
    PFX##_w_dequeue, PFX##_w_count, PFX##_w_counters, PFX##_w_snapshot };

DEFINE_IMPL(sq, "shift")
DEFINE_IMPL(cq, "circular")

typedef struct {
    const char *name;
    int arrivals;
    int service;
    int period;
    int burst_len;
    int burst_extra;
} Scenario;

typedef struct {
    QueueCounters counters;
    int final_count;
    int max_count;
    int identical;
    int conserved;
} RunResult;

typedef struct {
    Packet *packets;
    long count;
} Dataset;

static const Scenario SCENARIOS[] = {
    {"nominal", 3, 4, 0, 0, 0},
    {"burst", 3, 4, 500, 50, 12},
    {"overload", 6, 4, 0, 0, 0}
};
static const OverflowPolicy POLICIES[] = {POLICY_REJECT_NEW, POLICY_OVERWRITE_OLDEST};
static const int REPLAY_CAPS[] = {8, 16, 32, 64, 128, 256, 512, 1024, 4096};
static const int MICRO_CAPS[] = {16, 64, 256, 1024, 4096, 16384};
static const long DEFAULT_SIZES[] = {5000, 20000, 100000};

static unsigned long long rng_state = 0x9E3779B97F4A7C15ULL;

static unsigned rng(void)
{
    rng_state = rng_state * 6364136223846793005ULL + 1442695040888963407ULL;
    return (unsigned)(rng_state >> 33);
}

static double now_ns(void)
{
    struct timespec t;
    timespec_get(&t, TIME_UTC);
    return (double)t.tv_sec * 1e9 + (double)t.tv_nsec;
}

static Packet *generate_packets(long n)
{
    Packet *v = malloc(sizeof(Packet) * (size_t)n);
    long long ts = 0;
    if (!v)
        return NULL;
    for (long i = 0; i < n; i++) {
        unsigned r = rng() % 100;
        int proto = r < 45 ? PROTO_TCP : r < 70 ? PROTO_UDP : r < 85 ? PROTO_HTTP : r < 95 ? PROTO_DNS : PROTO_ICMP;
        ts += 1 + rng() % 5;
        v[i].timestamp = ts;
        v[i].source = 0x0A000000u | (rng() % 50 + 1);
        v[i].destination = 0x0A000100u | (rng() % 50 + 1);
        v[i].protocol = proto;
        v[i].size = proto == PROTO_ICMP ? 64 : proto == PROTO_DNS ? 80 + (int)(rng() % 121) : 40 + (int)(rng() % 1461);
    }
    return v;
}

static int parse_ip(const char *s, uint32_t *out)
{
    unsigned a, b, c, d;
    if (sscanf(s, "%u.%u.%u.%u", &a, &b, &c, &d) != 4 || a > 255 || b > 255 || c > 255 || d > 255)
        return 0;
    *out = (a << 24) | (b << 16) | (c << 8) | d;
    return 1;
}

static Packet *load_csv(const char *path, long *n)
{
    FILE *f = fopen(path, "r");
    long cap = 1024, cnt = 0;
    Packet *v;
    char line[256];
    if (!f)
        return NULL;
    v = malloc(sizeof(Packet) * (size_t)cap);
    while (v && fgets(line, sizeof line, f)) {
        long long ts;
        char s[32], d[32], p[16];
        int sz;
        Packet k;
        if (sscanf(line, "%lld,%31[^,],%31[^,],%15[^,],%d", &ts, s, d, p, &sz) != 5)
            continue;
        k.timestamp = ts;
        if (!parse_ip(s, &k.source) || !parse_ip(d, &k.destination))
            continue;
        k.protocol = protocol_from_name(p);
        k.size = sz;
        if (cnt == cap) {
            Packet *nv;
            cap *= 2;
            nv = realloc(v, sizeof(Packet) * (size_t)cap);
            if (!nv) {
                free(v);
                fclose(f);
                return NULL;
            }
            v = nv;
        }
        v[cnt++] = k;
    }
    fclose(f);
    *n = cnt;
    return v;
}

static int *build_ops(const Scenario *s, long npk, long *nops)
{
    int *ops = malloc(sizeof(int) * (size_t)(npk * 4 + 64));
    long n = 0, next = 0;
    if (!ops)
        return NULL;
    for (long t = 0; next < npk; t++) {
        int a = s->arrivals;
        if (s->period > 0 && (t % s->period) < s->burst_len)
            a += s->burst_extra;
        for (int i = 0; i < a && next < npk; i++)
            ops[n++] = (int)next++;
        for (int i = 0; i < s->service; i++)
            ops[n++] = -1;
    }
    *nops = n;
    return ops;
}

static RunResult verify_run(const QueueImpl *A, const QueueImpl *B, int cap, OverflowPolicy pol,
                            const Packet *pk, const int *ops, long nops,
                            FILE *occ, long size, const char *scn)
{
    RunResult r;
    void *a = A->create(cap, pol);
    void *b = B->create(cap, pol);
    long step = nops / 100;
    Packet *sa = malloc(sizeof(Packet) * (size_t)cap);
    Packet *sb = malloc(sizeof(Packet) * (size_t)cap);
    memset(&r, 0, sizeof r);
    r.identical = 1;
    r.conserved = 1;
    if (step < 1)
        step = 1;
    for (long i = 0; i < nops; i++) {
        int op = ops[i];
        int ca;
        if (op >= 0) {
            if (A->enqueue(a, &pk[op]) != B->enqueue(b, &pk[op]))
                r.identical = 0;
        } else {
            Packet pa, pb;
            int ra = A->dequeue(a, &pa);
            int rb = B->dequeue(b, &pb);
            if (ra != rb || (ra && !packet_equal(&pa, &pb)))
                r.identical = 0;
        }
        ca = A->count(a);
        if (ca != B->count(b))
            r.identical = 0;
        if (ca > r.max_count)
            r.max_count = ca;
        if (i % step == 0) {
            QueueCounters xa = A->counters(a), xb = B->counters(b);
            if (memcmp(&xa, &xb, sizeof xa) != 0)
                r.identical = 0;
            if (!counters_conserved(&xa, ca) || !counters_conserved(&xb, ca))
                r.conserved = 0;
            if (occ)
                fprintf(occ, "%ld,%s,%s,%d,%ld,%d\n", size, scn, policy_name(pol), cap, i, ca);
        }
    }
    {
        int na = A->snapshot(a, sa), nb = B->snapshot(b, sb);
        QueueCounters xa = A->counters(a), xb = B->counters(b);
        if (na != nb)
            r.identical = 0;
        else
            for (int i = 0; i < na; i++)
                if (!packet_equal(&sa[i], &sb[i]))
                    r.identical = 0;
        if (memcmp(&xa, &xb, sizeof xa) != 0)
            r.identical = 0;
        if (!counters_conserved(&xa, na) || !counters_conserved(&xb, nb))
            r.conserved = 0;
        r.counters = xa;
        r.final_count = na;
    }
    free(sa);
    free(sb);
    A->destroy(a);
    B->destroy(b);
    return r;
}

static double replay_ms(const QueueImpl *I, int cap, OverflowPolicy pol,
                        const Packet *pk, const int *ops, long nops)
{
    double best = 1e300;
    volatile long sink = 0;
    for (int rep = 0; rep < 3; rep++) {
        void *q = I->create(cap, pol);
        Packet out;
        double t0 = now_ns();
        for (long i = 0; i < nops; i++) {
            if (ops[i] >= 0) {
                I->enqueue(q, &pk[ops[i]]);
            } else if (I->dequeue(q, &out)) {
                sink += out.size;
            }
        }
        double t1 = now_ns();
        I->destroy(q);
        if (t1 - t0 < best)
            best = t1 - t0;
    }
    (void)sink;
    return best / 1e6;
}

static void micro_bench(const QueueImpl *impls[2], FILE *out)
{
    Packet *pk = generate_packets(16384);
    volatile long sink = 0;
    fprintf(out, "capacity,impl,enqueue_ns,dequeue_ns,enqueue_full_overwrite_ns\n");
    printf("\nMicro-benchmark (ns par operation)\n");
    printf("%-9s %-9s %12s %12s %16s\n", "capacite", "file", "enqueue", "dequeue", "enq. pleine+ecr.");
    for (int ci = 0; ci < LEN(MICRO_CAPS); ci++) {
        int cap = MICRO_CAPS[ci];
        int reps = 200000 / cap;
        if (reps < 5)
            reps = 5;
        for (int ii = 0; ii < 2; ii++) {
            const QueueImpl *I = impls[ii];
            double te = 0, td = 0, to = 0, ops = (double)cap * reps;
            Packet o;
            for (int r = 0; r < reps; r++) {
                void *q = I->create(cap, POLICY_REJECT_NEW);
                double t0 = now_ns();
                for (int i = 0; i < cap; i++)
                    I->enqueue(q, &pk[i]);
                double t1 = now_ns();
                for (int i = 0; i < cap; i++)
                    if (I->dequeue(q, &o))
                        sink += o.size;
                double t2 = now_ns();
                I->destroy(q);
                te += t1 - t0;
                td += t2 - t1;
            }
            for (int r = 0; r < reps; r++) {
                void *q = I->create(cap, POLICY_OVERWRITE_OLDEST);
                for (int i = 0; i < cap; i++)
                    I->enqueue(q, &pk[i]);
                double t0 = now_ns();
                for (int i = 0; i < cap; i++)
                    I->enqueue(q, &pk[i]);
                double t1 = now_ns();
                I->destroy(q);
                to += t1 - t0;
            }
            fprintf(out, "%d,%s,%.2f,%.2f,%.2f\n", cap, I->name, te / ops, td / ops, to / ops);
            printf("%-9d %-9s %12.2f %12.2f %16.2f\n", cap, I->name, te / ops, td / ops, to / ops);
        }
    }
    (void)sink;
    free(pk);
}

static FILE *open_out(const char *dir, const char *name)
{
    char path[512];
    snprintf(path, sizeof path, "%s/%s", dir, name);
    FILE *f = fopen(path, "w");
    if (!f)
        fprintf(stderr, "impossible d'ecrire %s\n", path);
    return f;
}

int main(int argc, char **argv)
{
    const char *outdir = "out";
    const char *csv_paths[MAX_DATASETS];
    int ncsv = 0;
    Dataset sets[MAX_DATASETS];
    int nsets = 0;
    const QueueImpl *impls[2] = {&sq_impl, &cq_impl};
    FILE *fbench, *fover, *focc;
    int runs = 0, not_identical = 0, not_conserved = 0, shown = 0;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--out") == 0 && i + 1 < argc) {
            outdir = argv[++i];
        } else if (strcmp(argv[i], "--csv") == 0 && i + 1 < argc && ncsv < MAX_DATASETS) {
            csv_paths[ncsv++] = argv[++i];
        } else {
            fprintf(stderr, "usage : %s [--out dossier] [--csv fichier.csv ...]\n", argv[0]);
            return 2;
        }
    }

    if (ncsv > 0) {
        for (int i = 0; i < ncsv; i++) {
            sets[nsets].packets = load_csv(csv_paths[i], &sets[nsets].count);
            if (!sets[nsets].packets || sets[nsets].count == 0) {
                fprintf(stderr, "lecture impossible ou vide : %s\n", csv_paths[i]);
                return 1;
            }
            nsets++;
        }
    } else {
        for (int i = 0; i < LEN(DEFAULT_SIZES); i++) {
            sets[nsets].count = DEFAULT_SIZES[i];
            sets[nsets].packets = generate_packets(DEFAULT_SIZES[i]);
            nsets++;
        }
    }

    MKDIR(outdir);
    fbench = open_out(outdir, "bench_time.csv");
    fover = open_out(outdir, "overflow.csv");
    focc = open_out(outdir, "occupancy.csv");
    if (!fbench || !fover || !focc)
        return 1;

    micro_bench(impls, fbench);

    fprintf(fover, "dataset_size,scenario,policy,capacity,received,accepted,rejected,overwritten,removed,"
                   "final_count,max_occupancy,loss_rate,replay_ms_shift,replay_ms_circular,identical,conserved\n");
    fprintf(focc, "dataset_size,scenario,policy,capacity,op_index,occupancy\n");

    for (int si = 0; si < nsets; si++) {
        long size = sets[si].count;
        for (int sc = 0; sc < LEN(SCENARIOS); sc++) {
            long nops = 0;
            int *ops = build_ops(&SCENARIOS[sc], size, &nops);
            if (!ops)
                return 1;
            for (int pi = 0; pi < LEN(POLICIES); pi++) {
                for (int ci = 0; ci < LEN(REPLAY_CAPS); ci++) {
                    int cap = REPLAY_CAPS[ci];
                    RunResult r = verify_run(&sq_impl, &cq_impl, cap, POLICIES[pi], sets[si].packets,
                                             ops, nops, focc, size, SCENARIOS[sc].name);
                    double ms_s = replay_ms(&sq_impl, cap, POLICIES[pi], sets[si].packets, ops, nops);
                    double ms_c = replay_ms(&cq_impl, cap, POLICIES[pi], sets[si].packets, ops, nops);
                    double loss = r.counters.received
                        ? (double)(r.counters.rejected + r.counters.overwritten) / (double)r.counters.received : 0.0;
                    runs++;
                    if (!r.identical)
                        not_identical++;
                    if (!r.conserved)
                        not_conserved++;
                    fprintf(fover, "%ld,%s,%s,%d,%lu,%lu,%lu,%lu,%lu,%d,%d,%.6f,%.3f,%.3f,%d,%d\n",
                            size, SCENARIOS[sc].name, policy_name(POLICIES[pi]), cap,
                            r.counters.received, r.counters.accepted, r.counters.rejected,
                            r.counters.overwritten, r.counters.removed, r.final_count, r.max_count,
                            loss, ms_s, ms_c, r.identical, r.conserved);
                    if (si == (nsets > 1 ? 1 : 0) && sc == 1 && pi == 0) {
                        if (!shown) {
                            printf("\nRafales (dataset %ld paquets, rejet du nouveau paquet)\n", size);
                            printf("%-9s %9s %9s %8s %12s %12s %9s\n", "capacite", "recus", "rejetes", "perte",
                                   "shift (ms)", "circ. (ms)", "x plus lent");
                            shown = 1;
                        }
                        printf("%-9d %9lu %9lu %7.1f%% %12.2f %12.2f %9.1f\n", cap, r.counters.received,
                               r.counters.rejected, loss * 100.0, ms_s, ms_c, ms_c > 0 ? ms_s / ms_c : 0.0);
                    }
                }
            }
            free(ops);
        }
    }

    printf("\nSynthese : %d simulations, %d avec resultats differents entre les deux files, "
           "%d avec compteurs non conserves\n", runs, not_identical, not_conserved);
    printf("Fichiers ecrits dans %s/ : bench_time.csv, overflow.csv, occupancy.csv\n", outdir);

    fclose(fbench);
    fclose(fover);
    fclose(focc);
    for (int i = 0; i < nsets; i++)
        free(sets[i].packets);
    return (not_identical || not_conserved) ? 1 : 0;
}
