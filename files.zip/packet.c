#include <string.h>
#include "packet.h"

static const char *NAMES[PROTO_COUNT] = {"TCP", "UDP", "ICMP", "HTTP", "DNS", "OTHER"};

int packet_equal(const Packet *a, const Packet *b)
{
    return a->timestamp == b->timestamp
        && a->source == b->source
        && a->destination == b->destination
        && a->protocol == b->protocol
        && a->size == b->size;
}

const char *protocol_name(int protocol)
{
    if (protocol >= 0 && protocol < PROTO_COUNT)
        return NAMES[protocol];
    return NAMES[PROTO_OTHER];
}

int protocol_from_name(const char *name)
{
    for (int i = 0; i < PROTO_OTHER; i++)
        if (strcmp(name, NAMES[i]) == 0)
            return i;
    return PROTO_OTHER;
}
