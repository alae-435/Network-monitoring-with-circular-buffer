#ifndef PACKET_H
#define PACKET_H

#include <stdint.h>

typedef enum {
    PROTO_TCP,
    PROTO_UDP,
    PROTO_ICMP,
    PROTO_HTTP,
    PROTO_DNS,
    PROTO_OTHER,
    PROTO_COUNT
} Protocol;

typedef struct {
    long long timestamp;
    uint32_t source;
    uint32_t destination;
    int protocol;
    int size;
} Packet;

int packet_equal(const Packet *a, const Packet *b);
const char *protocol_name(int protocol);
int protocol_from_name(const char *name);

#endif
