#ifndef QUEUE_COMMON_H
#define QUEUE_COMMON_H

#include "packet.h"

typedef enum {
    POLICY_OVERWRITE_OLDEST,
    POLICY_REJECT_NEW
} OverflowPolicy;

typedef enum {
    ENQ_OK,
    ENQ_OVERWROTE,
    ENQ_REJECTED
} EnqueueResult;

typedef struct {
    unsigned long received;
    unsigned long accepted;
    unsigned long rejected;
    unsigned long overwritten;
    unsigned long removed;
} QueueCounters;

static inline int counters_conserved(const QueueCounters *c, int count)
{
    return c->received == c->accepted + c->rejected
        && c->accepted == c->removed + c->overwritten + (unsigned long)count;
}

static inline const char *policy_name(OverflowPolicy p)
{
    return p == POLICY_OVERWRITE_OLDEST ? "overwrite_oldest" : "reject_new";
}

#endif
