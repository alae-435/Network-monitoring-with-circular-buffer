#include <stdlib.h>
#include <string.h>
#include "ref_queue.h"

struct ShiftQueue {
    Packet *data;
    int capacity;
    int count;
    OverflowPolicy policy;
    QueueCounters counters;
};

ShiftQueue *sq_create(int capacity, OverflowPolicy policy)
{
    if (capacity < 1)
        return NULL;
    ShiftQueue *q = calloc(1, sizeof *q);
    if (!q)
        return NULL;
    q->data = malloc(sizeof(Packet) * (size_t)capacity);
    if (!q->data) {
        free(q);
        return NULL;
    }
    q->capacity = capacity;
    q->policy = policy;
    return q;
}

void sq_destroy(ShiftQueue *q)
{
    if (!q)
        return;
    free(q->data);
    free(q);
}

EnqueueResult sq_enqueue(ShiftQueue *q, const Packet *p)
{
    q->counters.received++;
    if (q->count == q->capacity) {
        if (q->policy == POLICY_REJECT_NEW) {
            q->counters.rejected++;
            return ENQ_REJECTED;
        }
        memmove(q->data, q->data + 1, sizeof(Packet) * (size_t)(q->count - 1));
        q->data[q->count - 1] = *p;
        q->counters.accepted++;
        q->counters.overwritten++;
        return ENQ_OVERWROTE;
    }
    q->data[q->count++] = *p;
    q->counters.accepted++;
    return ENQ_OK;
}

int sq_dequeue(ShiftQueue *q, Packet *out)
{
    if (q->count == 0)
        return 0;
    if (out)
        *out = q->data[0];
    memmove(q->data, q->data + 1, sizeof(Packet) * (size_t)(q->count - 1));
    q->count--;
    q->counters.removed++;
    return 1;
}

int sq_peek(const ShiftQueue *q, Packet *out)
{
    if (q->count == 0)
        return 0;
    *out = q->data[0];
    return 1;
}

void sq_clear(ShiftQueue *q)
{
    q->count = 0;
    memset(&q->counters, 0, sizeof q->counters);
}

int sq_count(const ShiftQueue *q)
{
    return q->count;
}

int sq_capacity(const ShiftQueue *q)
{
    return q->capacity;
}

QueueCounters sq_counters(const ShiftQueue *q)
{
    return q->counters;
}

int sq_snapshot(const ShiftQueue *q, Packet *out)
{
    memcpy(out, q->data, sizeof(Packet) * (size_t)q->count);
    return q->count;
}
