#ifndef REF_QUEUE_H
#define REF_QUEUE_H

#include "queue_common.h"

typedef struct ShiftQueue ShiftQueue;

ShiftQueue *sq_create(int capacity, OverflowPolicy policy);
void sq_destroy(ShiftQueue *q);
EnqueueResult sq_enqueue(ShiftQueue *q, const Packet *p);
int sq_dequeue(ShiftQueue *q, Packet *out);
int sq_peek(const ShiftQueue *q, Packet *out);
void sq_clear(ShiftQueue *q);
int sq_count(const ShiftQueue *q);
int sq_capacity(const ShiftQueue *q);
QueueCounters sq_counters(const ShiftQueue *q);
int sq_snapshot(const ShiftQueue *q, Packet *out);

#endif
