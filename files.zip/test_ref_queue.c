#include <stdio.h>
#include <stdlib.h>
#include "ref_queue.h"
#include "circ_queue.h"

static int checks = 0;
static int failures = 0;

#define CHECK(c) do { checks++; if (!(c)) { failures++; printf("ECHEC ligne %d : %s\n", __LINE__, #c); } } while (0)

static Packet mk(int i)
{
    Packet p;
    p.timestamp = i;
    p.source = (uint32_t)i;
    p.destination = (uint32_t)i + 1;
    p.protocol = i % PROTO_COUNT;
    p.size = 40 + i;
    return p;
}

static void test_create(void)
{
    CHECK(sq_create(0, POLICY_REJECT_NEW) == NULL);
    CHECK(sq_create(-3, POLICY_REJECT_NEW) == NULL);
    ShiftQueue *q = sq_create(4, POLICY_REJECT_NEW);
    CHECK(q != NULL);
    CHECK(sq_capacity(q) == 4);
    sq_destroy(q);
}

static void test_empty(void)
{
    ShiftQueue *q = sq_create(4, POLICY_REJECT_NEW);
    Packet p;
    CHECK(sq_count(q) == 0);
    CHECK(sq_dequeue(q, &p) == 0);
    CHECK(sq_peek(q, &p) == 0);
    CHECK(sq_snapshot(q, &p) == 0);
    CHECK(sq_counters(q).removed == 0);
    sq_destroy(q);
}

static void test_fifo(void)
{
    ShiftQueue *q = sq_create(5, POLICY_REJECT_NEW);
    Packet p;
    for (int i = 0; i < 5; i++) {
        p = mk(i);
        CHECK(sq_enqueue(q, &p) == ENQ_OK);
    }
    CHECK(sq_count(q) == 5);
    CHECK(sq_peek(q, &p) == 1 && p.timestamp == 0);
    for (int i = 0; i < 5; i++) {
        CHECK(sq_dequeue(q, &p) == 1);
        CHECK(p.timestamp == i);
    }
    CHECK(sq_count(q) == 0);
    sq_destroy(q);
}

static void test_full_reject(void)
{
    ShiftQueue *q = sq_create(3, POLICY_REJECT_NEW);
    Packet a[3], p;
    for (int i = 0; i < 3; i++) {
        p = mk(i);
        sq_enqueue(q, &p);
    }
    p = mk(99);
    CHECK(sq_enqueue(q, &p) == ENQ_REJECTED);
    CHECK(sq_count(q) == 3);
    CHECK(sq_snapshot(q, a) == 3);
    CHECK(a[0].timestamp == 0 && a[1].timestamp == 1 && a[2].timestamp == 2);
    QueueCounters c = sq_counters(q);
    CHECK(c.received == 4 && c.accepted == 3 && c.rejected == 1 && c.overwritten == 0);
    CHECK(counters_conserved(&c, sq_count(q)));
    sq_destroy(q);
}

static void test_full_overwrite(void)
{
    ShiftQueue *q = sq_create(3, POLICY_OVERWRITE_OLDEST);
    Packet a[3], p;
    for (int i = 0; i < 3; i++) {
        p = mk(i);
        sq_enqueue(q, &p);
    }
    p = mk(10);
    CHECK(sq_enqueue(q, &p) == ENQ_OVERWROTE);
    p = mk(11);
    CHECK(sq_enqueue(q, &p) == ENQ_OVERWROTE);
    CHECK(sq_snapshot(q, a) == 3);
    CHECK(a[0].timestamp == 2 && a[1].timestamp == 10 && a[2].timestamp == 11);
    QueueCounters c = sq_counters(q);
    CHECK(c.received == 5 && c.accepted == 5 && c.overwritten == 2 && c.rejected == 0);
    CHECK(counters_conserved(&c, sq_count(q)));
    sq_destroy(q);
}

static void test_capacity_one(void)
{
    OverflowPolicy pols[2] = {POLICY_REJECT_NEW, POLICY_OVERWRITE_OLDEST};
    for (int k = 0; k < 2; k++) {
        ShiftQueue *q = sq_create(1, pols[k]);
        Packet p = mk(1), o;
        CHECK(sq_enqueue(q, &p) == ENQ_OK);
        p = mk(2);
        if (pols[k] == POLICY_REJECT_NEW) {
            CHECK(sq_enqueue(q, &p) == ENQ_REJECTED);
            CHECK(sq_peek(q, &o) && o.timestamp == 1);
        } else {
            CHECK(sq_enqueue(q, &p) == ENQ_OVERWROTE);
            CHECK(sq_peek(q, &o) && o.timestamp == 2);
        }
        CHECK(sq_dequeue(q, &o) == 1);
        CHECK(sq_dequeue(q, &o) == 0);
        QueueCounters c = sq_counters(q);
        CHECK(counters_conserved(&c, sq_count(q)));
        sq_destroy(q);
    }
}

static void test_shift_after_removal(void)
{
    ShiftQueue *q = sq_create(4, POLICY_REJECT_NEW);
    Packet a[4], p, o;
    for (int i = 0; i < 4; i++) {
        p = mk(i);
        sq_enqueue(q, &p);
    }
    sq_dequeue(q, &o);
    sq_dequeue(q, &o);
    CHECK(sq_count(q) == 2);
    p = mk(4);
    CHECK(sq_enqueue(q, &p) == ENQ_OK);
    p = mk(5);
    CHECK(sq_enqueue(q, &p) == ENQ_OK);
    p = mk(6);
    CHECK(sq_enqueue(q, &p) == ENQ_REJECTED);
    CHECK(sq_snapshot(q, a) == 4);
    CHECK(a[0].timestamp == 2 && a[1].timestamp == 3 && a[2].timestamp == 4 && a[3].timestamp == 5);
    sq_destroy(q);
}

static void test_clear(void)
{
    ShiftQueue *q = sq_create(4, POLICY_REJECT_NEW);
    Packet p, o;
    for (int i = 0; i < 6; i++) {
        p = mk(i);
        sq_enqueue(q, &p);
    }
    sq_clear(q);
    CHECK(sq_count(q) == 0);
    CHECK(sq_dequeue(q, &o) == 0);
    QueueCounters c = sq_counters(q);
    CHECK(c.received == 0 && c.accepted == 0 && c.rejected == 0 && c.removed == 0);
    p = mk(7);
    CHECK(sq_enqueue(q, &p) == ENQ_OK);
    CHECK(sq_peek(q, &o) && o.timestamp == 7);
    sq_destroy(q);
}

static unsigned long long state = 88172645463325252ULL;

static unsigned rnd(void)
{
    state ^= state << 13;
    state ^= state >> 7;
    state ^= state << 17;
    return (unsigned)(state >> 11);
}

static void test_equivalence_with_circular(void)
{
    int caps[] = {1, 2, 3, 8, 64};
    OverflowPolicy pols[2] = {POLICY_REJECT_NEW, POLICY_OVERWRITE_OLDEST};
    int wrapped = 0;
    for (int ci = 0; ci < 5; ci++) {
        for (int pi = 0; pi < 2; pi++) {
            ShiftQueue *s = sq_create(caps[ci], pols[pi]);
            CircQueue *c = cq_create(caps[ci], pols[pi]);
            Packet sa[64], ca[64];
            int ok = 1;
            for (int i = 0; i < 100000 && ok; i++) {
                if (rnd() % 100 < 55) {
                    Packet p = mk(i);
                    ok &= sq_enqueue(s, &p) == cq_enqueue(c, &p);
                } else {
                    Packet a, b;
                    int ra = sq_dequeue(s, &a), rb = cq_dequeue(c, &b);
                    ok &= ra == rb && (!ra || packet_equal(&a, &b));
                }
                ok &= sq_count(s) == cq_count(c);
                if (cq_tail(c) < cq_head(c))
                    wrapped = 1;
            }
            ok &= sq_snapshot(s, sa) == cq_snapshot(c, ca);
            for (int i = 0; i < sq_count(s); i++)
                ok &= packet_equal(&sa[i], &ca[i]);
            QueueCounters x = sq_counters(s), y = cq_counters(c);
            ok &= x.received == y.received && x.accepted == y.accepted && x.rejected == y.rejected
               && x.overwritten == y.overwritten && x.removed == y.removed;
            ok &= counters_conserved(&x, sq_count(s));
            CHECK(ok);
            sq_destroy(s);
            cq_destroy(c);
        }
    }
    CHECK(wrapped);
}

int main(void)
{
    test_create();
    test_empty();
    test_fifo();
    test_full_reject();
    test_full_overwrite();
    test_capacity_one();
    test_shift_after_removal();
    test_clear();
    test_equivalence_with_circular();
    printf("%d verifications, %d echec(s)\n", checks, failures);
    return failures ? 1 : 0;
}
